import aiohttp
import discord
from discord.ext import commands
import wavelink,json
import asyncio
from pystyle import Center, Colorate, Colors
import random
import requests
from datetime import datetime
import pytz
def time():
    timezone = pytz.timezone(time_zone)
    time = datetime.now(timezone)
    return time.strftime("%I:%M %p")

def load_config():
    with open('music_config.json', 'r') as f:
        return json.load(f)
def load_config2():
    with open('config.json', 'r') as f:
        return json.load(f)

config = load_config()
config2 = load_config2()
OWNER_ID = config['allowed_users']
music_token = config['token']
async def get_prefix(bot, message):
    config = load_config()
    return config.get("prefix", ",")
prefix = get_prefix
time_zone = config2['time_zone']
queues = {}  
skipped_tracks = {}
player_text_channels = {}
bot = commands.Bot(command_prefix=prefix,help_command=None)

@bot.event
async def on_ready():
    ascii = f"""[-]================================] | [ Music alt : {bot.user.name} ] | [================================[-]"""
    print(Colorate.Horizontal(Colors.blue_to_cyan, Center.XCenter(ascii)))
    host = config["lavalink_host"]
    port = config["lavalink_port"]
    password = config["lavalink_password"]
    https = config["lavalink_https"]
    uri = f"https://{host}:{port}" if https else f"http://{host}:{port}"
    nodes = [wavelink.Node(uri=uri, password=password)]
    await wavelink.Pool.connect(nodes=nodes, client=bot, cache_capacity=100)

async def send(ctx,message: str,delete_after : int= None):
    msg =await ctx.reply(f"{message}")
    await delete_message(ctx.message.id, ctx.channel.id)
    return msg

def is_owner(ctx):
    return ctx.author.id in OWNER_ID

def delete_message(msg_id, channel_id):
    with open('config.json', 'r') as config_file:
        config = json.load(config_file)
    token = config.get("token")    
    url = f"https://discord.com/api/v9/channels/{channel_id}/messages/{msg_id}"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    response = requests.delete(url, headers=headers)
    if response.status_code == 204:
        pass
    else:
        pass

@bot.command()
async def join(ctx: commands.Context, channel: discord.VoiceChannel = None):
    if not is_owner(ctx):
        return

    if channel:
        if not isinstance(channel, discord.VoiceChannel):
            return await send(ctx, ":x: **The provided channel ID is not a valid voice channel.** ")
    else:
        if ctx.author.voice and ctx.author.voice.channel:
            channel = ctx.author.voice.channel
        else:
            return await send(ctx, ":x: **You must join a voice channel before using this command.** ")
    player = ctx.voice_client
    if not player:
        try:
            player = await channel.connect(cls=wavelink.Player)
            await send(ctx, f":white_check_mark: **Joined `{channel.name}` successfully.** ")
        except discord.ClientException:
            await send(ctx, ":x: **I couldn't join the voice channel. Please try again.** ")
    else:
        await send(ctx, ":warning: **I'm already connected to a voice channel.** ")

@bot.command()
async def play(ctx: commands.Context, *, query: str) -> None:
    if not is_owner(ctx):
        return
    if not ctx.guild:
        return
    player = ctx.voice_client
    if not player:
        try:
            player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
        except AttributeError:
            await ctx.reply("> ❌ **You must be in a voice channel to use this command.**")
            return await delete_message(ctx.message.id, ctx.channel.id)
        except discord.ClientException:
            await ctx.reply("> ❌ **I was unable to join the voice channel.**\n> **Please check my permissions and try again.**")
            return await delete_message(ctx.message.id, ctx.channel.id)
    tracks = await wavelink.Playable.search(query)
    if not tracks:
        await ctx.reply(f"> ⚠️ **{ctx.author.mention}, no tracks were found for your query:** `{query}`\nPlease refine your search and try again.")
        return await delete_message(ctx.message.id, ctx.channel.id)
    if isinstance(tracks, wavelink.Playlist):
        for track in tracks.tracks:
            await player.queue.put_wait(track)
        await ctx.reply(f"> ✅ **Playlist Added:** `{tracks.name}` *(Total Tracks: {len(tracks.tracks)})* has been successfully added to the queue. 🎶")
    else:
        track = tracks[0]
        minutes, seconds = divmod(track.length // 1000, 60)
        duration = f"{minutes}:{seconds:02d}" 
        await player.queue.put_wait(track)
        await ctx.reply(
            f"> 🎵 **Track Added:** `{track.title}`\n"
            f"> 🎤 **Artist:** `{track.author}`\n"
            f"> ⏳ **Duration:** `{duration}`\n"
            f"> 🔍 **Search Query:** `{query}` ✅"
        )
        await delete_message(ctx.message.id, ctx.channel.id)
    if not player.playing:
        await player.play(await player.queue.get_wait(), volume=30)

@bot.command()
async def queue(ctx: commands.Context):
    if not is_owner(ctx):
        return
    player = ctx.voice_client
    if not player or player.queue.is_empty:
        return await send(ctx,"> :x: **The queue is currently empty.**")
    queue_list = "\n".join([f"{i+1}. {track.title}" for i, track in enumerate(player.queue)])
    await send(ctx,f">>> 🎶 **Current Queue:**\n```{queue_list}```")

@bot.command()
async def clearqueue(ctx: commands.Context):
    if not is_owner(ctx):
        return


    player = ctx.voice_client
    if not player:
        return await send(ctx,"> :x: **No active player found.**")

    player.queue.clear()
    await send(ctx,"> :white_check_mark: **The song queue has been cleared successfully.**")

@bot.command()
async def tts(ctx, *, message: str):
    if not is_owner(ctx):
        return

    if not ctx.author.voice or not ctx.author.voice.channel:
        return await send(ctx, "> :x: **Please join a voice channel first.**")

    player: wavelink.Player = ctx.voice_client
    if not player:
        try:
            player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
        except discord.ClientException:
            return await send(ctx, "> :x: **I couldn't join the voice channel.**")

    msg = await send(ctx, "> :repeat: **Converting text to speech...**")

    api_url = f"https://api.kastg.xyz/api/ai/tts?input={message}&lang=English&voice=Emily"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(api_url) as response:
            if response.status != 200:
                return await send(ctx, "> :x: **Failed to fetch TTS audio.**")
            data = await response.json()

    if not data.get("status") or "result" not in data or not data["result"]:
        return await send(ctx, "> :x: **Invalid response from TTS API.**")

    tts_url = data["result"][0]["url"]
    tracks = await wavelink.Playable.search(tts_url)
    if not tracks:
        return await send(ctx, "> :x: **Failed to load TTS audio.**")

    track = tracks[0] if isinstance(tracks, list) else tracks
    await player.play(track)
    await msg.edit(content=f":microphone2: **Speaking: `{message}`**")

@bot.command(aliases=['skip'])
async def next(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return


    player = ctx.voice_client
    if not player:
        return
    
    if not player.queue.is_empty:
        next_track = await player.queue.get_wait()
        await player.play(next_track)
        msg = await send(ctx,"> :white_check_mark: **Skipped to the next track.**")
        await msg.reply(f"**:loud_sound: Now playing:** `{next_track.title}`")        
    else:
        await player.stop()
        await send(ctx,"> :white_check_mark: **No more songs in the queue. Stopping playback.**")

@bot.command()
async def stop(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return


    player = ctx.voice_client
    if not player:
        return
    await player.stop()
    await send(ctx,"> :white_check_mark: **Playback stopped successfuly.**")

@bot.command()
async def pause(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return


    player = ctx.voice_client
    if not player:
        return
    
    if not player.paused:
        await player.pause(True)  # :white_check_mark: Correct way to pause
        await send(ctx,"> :white_check_mark: **Music paused successfully.**")
    else:
        await send(ctx,"> :warning: **Music is already paused.**")

@bot.command()
async def resume(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return


    player = ctx.voice_client
    if not player:
        return
    
    if player.paused:
        await player.pause(False)  # :white_check_mark: Correct way to resume
        await send(ctx,"> :white_check_mark: **Music resumed successfully.**")
    else:
        await send(ctx,"> :warning: **Music is already playing.**")

loop_mode = {}

@bot.command()
async def loop(ctx: commands.Context):
    if not is_owner(ctx):
        return


    player = ctx.voice_client
    if not player or not player.current:
        return await send(ctx,"> :x: **No song is currently playing.**")

    guild_id = ctx.guild.id
    loop_mode[guild_id] = not loop_mode.get(guild_id, False)

    if loop_mode[guild_id]:
        await send(ctx,f"> :repeat: **Looping enabled for `{player.current.title}`.**")
    else:
        await send(ctx,f"> :stop_button: **Looping disabled for `{player.current.title}`.**")

@bot.command(aliases=["shuf"])
async def shuffle(ctx):
    if not is_owner(ctx):
        return    

    queue = queues.get(ctx.guild.id, [])
    if len(queue) > 1:
        random.shuffle(queue)
        await send(ctx,"> Queue has been shuffled.")
    else:
        await send(ctx,"> Not enough tracks to shuffle.")

@bot.command(aliases=[ 'np','nowp'])
async def nowplaying(ctx):
    if not is_owner(ctx):
        return    

    player = ctx.guild.voice_client
    if not player or not player.current:
        await send(ctx,"> No track is currently playing.")
        return
    track = player.current
    await send(ctx,f"> :loud_sound: Now playing:** `{track.title}`")

@bot.command(aliases=["vol", "setvol"])
async def volume(ctx, volume: int = None):
    if not is_owner(ctx):
        return

    player = ctx.guild.voice_client
    if not player:
        await send(ctx,"> :x: I am not connected to a voice channel.")
        return

    if volume is None:
        current_volume = player.volume
        await send(ctx,f":loud_sound: **Current volume: {current_volume}%")
    else:
        if 0 <= volume <= 100:
            await player.set_volume(volume)
            await send(ctx,f":loud_sound: **Volume set to {volume}%.**")
        else:
            await send(ctx,"> Please provide a valid volume between 0 and 100.")

@bot.command(aliases=["dc", "leave"])
async def disconnect(ctx: commands.Context) -> None:
    if not is_owner(ctx):
        return

    player = ctx.voice_client
    if not player:
        return
    await player.disconnect()
    await send(ctx,"> :white_check_mark: **Disconnected from the voice channel.**")       

async def main():
    try: 
        await bot.start(music_token)      
    except discord.errors.LoginFailure:
        ascii = f"""[-]================================] | [ Invalid token ] | [================================[-]"""
        print(Colorate.Horizontal(Colors.blue_to_cyan, Center.XCenter(ascii)))

if __name__ == "__main__":
    asyncio.run(main())        